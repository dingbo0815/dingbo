# OS-4
終於解決了路徑問題以及sdk抓取問題花了很久，改了led的優先權，並更換角位，燒錄後將uf2檔丟入插入後的usb，因為import project一直產生不乾淨的路徑及build和vscode，所以直接繞過換成點左下角的齒輪build，終於出現exit0

為了解決 Windows 環境下「中文路徑」導致的編譯器崩潰問題，本實驗採取以下配置流程：
路徑標準化： 將所有開發工具 (SDK, Toolchain) 與專案統一放置於 C:\pico-sdk\，避開使用者資料夾中的中文字元。
環境變數設定： * PICO_SDK_PATH -> C:\pico-sdk\pico-sdk
PICO_TOOLCHAIN_PATH -> C:\pico-sdk\gcc-arm
編譯工具： * 編譯器： ARM GNU Toolchain 15.2
產生器： Ninja (解決 NMake 找不到路徑的問題)
編輯器： VS Code (搭配 CMake Tools 擴充功能)
