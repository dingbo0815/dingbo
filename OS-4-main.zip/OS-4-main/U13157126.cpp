/***
 * Demo program to flash 5 LED attached to GPIO PAD 0, 2,3,4, 5.
 * Uses FreeRTOS Task
 * Jon Durrant
 * 15-Aug-2022
 */


#include "pico/stdlib.h"

#include "FreeRTOS.h"
#include "task.h"
#include <stdio.h>

#include "BlinkAgent.h"


//Standard Task priority
#define TASK_PRIORITY		( tskIDLE_PRIORITY + 1UL )
#define LED_PAD   23
//LED PAD to use
#define LED1_PAD  10   
#define LED2_PAD  1   
#define LED3_PAD  2   
#define LED4_PAD  3   
#define LED5_PAD  4   
#define LED6_PAD  5   
#define LED7_PAD  6   
#define LED8_PAD  7   



void runTimeStats(   ){
	TaskStatus_t *pxTaskStatusArray;
	volatile UBaseType_t uxArraySize, x;
	unsigned long ulTotalRunTime;


   // Get number of takss
   uxArraySize = uxTaskGetNumberOfTasks();
   printf("Number of tasks %d\n", uxArraySize);

   //Allocate a TaskStatus_t structure for each task.
   pxTaskStatusArray = (TaskStatus_t *)pvPortMalloc( uxArraySize * sizeof( TaskStatus_t ) );

   if( pxTaskStatusArray != NULL ){
      // Generate raw status information about each task.
      uxArraySize = uxTaskGetSystemState( pxTaskStatusArray,
                                 uxArraySize,
                                 &ulTotalRunTime );

	 // Print stats
	 for( x = 0; x < uxArraySize; x++ )
	 {
		 printf("Task: %d \t cPri:%d \t bPri:%d \t hw:%d \t%s\n",
				pxTaskStatusArray[ x ].xTaskNumber ,
				pxTaskStatusArray[ x ].uxCurrentPriority ,
				pxTaskStatusArray[ x ].uxBasePriority ,
				pxTaskStatusArray[ x ].usStackHighWaterMark ,
				pxTaskStatusArray[ x ].pcTaskName
				);
	 }


      // Free array
      vPortFree( pxTaskStatusArray );
   } else {
	   printf("Failed to allocate space for stats\n");
   }

   //Get heap allocation information
   HeapStats_t heapStats;
   vPortGetHeapStats(&heapStats);
   printf("HEAP avl: %d, blocks %d, alloc: %d, free: %d\n",
		   heapStats.xAvailableHeapSpaceInBytes,
		   heapStats.xNumberOfFreeBlocks,
		   heapStats.xNumberOfSuccessfulAllocations,
		   heapStats.xNumberOfSuccessfulFrees
		   );
}


/***
 * Main task to blink external LED
 * @param params - unused
 */
void mainTask(void *params){
	BlinkAgent blink(23);
	BlinkAgent worker1(LED1_PAD);
	BlinkAgent worker2(LED2_PAD);
	BlinkAgent worker3(LED3_PAD);
	BlinkAgent worker4(LED4_PAD);
	BlinkAgent worker5(LED5_PAD);
	BlinkAgent worker6(LED6_PAD);
	BlinkAgent worker7(LED7_PAD);
	BlinkAgent worker8(LED8_PAD);

	printf("Main task started\n");

	blink.start("Blink", TASK_PRIORITY);
	worker1.start("Worker 1", TASK_PRIORITY);
	worker2.start("Worker 2", TASK_PRIORITY);
	worker3.start("Worker 3", TASK_PRIORITY);
	worker4.start("Worker 4", TASK_PRIORITY);
	worker5.start("Worker 5", TASK_PRIORITY);
	worker6.start("Worker 6", TASK_PRIORITY);
	worker7.start("Worker 7", TASK_PRIORITY);
	worker8.start("Worker 8", TASK_PRIORITY);

	while (true) { // Loop forever
		runTimeStats();
		vTaskDelay(3000);
	}
}




/***
 * Launch the tasks and scheduler
 */
void vLaunch( void) {

	//Start blink task
    TaskHandle_t task;
    xTaskCreate(mainTask, "MainThread", 500, NULL, TASK_PRIORITY, &task);

    /* Start the tasks and timer running. */
    vTaskStartScheduler();
}

/***
 * Main
 * @return
 */
int main( void )
{
	//Setup serial over USB and give a few seconds to settle before we start
    stdio_init_all();
    sleep_ms(2000);
    printf("GO\n");

    //Start tasks and scheduler
    const char *rtos_name = "FreeRTOS";
    printf("Starting %s on core 0:\n", rtos_name);
    vLaunch();


    return 0;
}
